package com.cap.jpaDemo;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="customerDetails")
public class Customer {
	
	@Id
	@GeneratedValue
	private Integer customerId;
	@Column(length=25)
	private String name;
	@Column(name="reg_fee",nullable=false)
	private Double regFee;
	@Column(unique=true)
	private Date regDate;
	public Customer() {
		super();
	}
	public Customer( String name, Double regFee, Date regDate) {
		super();
		//this.customerId = customerId;
		this.name = name;
		this.regFee = regFee;
		this.regDate = regDate;
	}
	public Integer getCustomerId() {
		return customerId;
	}
	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Double getRegFee() {
		return regFee;
	}
	public void setRegFee(Double regFee) {
		this.regFee = regFee;
	}
	public Date getRegDate() {
		return regDate;
	}
	public void setRegDate(Date regDate) {
		this.regDate = regDate;
	}
	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", name=" + name + ", regFee=" + regFee + ", regDate=" + regDate
				+ "]";
	}
	
	
	
	

}
