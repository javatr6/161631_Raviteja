package com.capg.manytomany;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class Tester {

	public static void main(String[] args) {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpademo");
		EntityManager entityManager=emf.createEntityManager();
		EntityTransaction transaction=entityManager.getTransaction();
		transaction.begin();
		Events oops=new Events();
		oops.setEventId("101-OOPS");
		oops.setEventName("OOPS");
		
		Events EP=new Events();
		EP.setEventId("102-EP");
		EP.setEventName("Ep");
		
		Delegates sri=new Delegates(1,"Sri");
		Delegates sai=new Delegates(2,"Sai");
		Delegates krishna=new Delegates(3,"Krishna");
		
		sri.getEvents().add(oops);
		sri.getEvents().add(EP);
		sai.getEvents().add(oops);
		krishna.getEvents().add(oops);
		
		entityManager.persist(oops);
		entityManager.persist(EP);
		
		entityManager.persist(sri);
		entityManager.persist(sai);
		entityManager.persist(krishna);
		
		
		
		
		
		
		transaction.commit();
		entityManager.close();

	}

}
