package com.capgemini.Product.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.Product.Dao.ICustomerDao;
import com.capgemini.Product.Dao.IInventoryDao;
import com.capgemini.Product.Model.Product;

@Service
public class InventoryService implements IinventoryService{
	
	@Autowired
	private ICustomerDao iCustomerDao;
	
	@Autowired
	private IInventoryDao productDao;

	@Override
	public List<Product> saveProduct(Product product) {
		productDao.save(product);
		return productDao.findAll();
	}

	@Override
	public List<Product> getAllProducts() {
		
		return productDao.findAll();
	}
	
	
	
	

} 
 
