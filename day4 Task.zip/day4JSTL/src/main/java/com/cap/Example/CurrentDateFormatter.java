package com.cap.Example;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.SimpleTagSupport;

public class CurrentDateFormatter extends SimpleTagSupport{
	
	String format;

	public void setFormat(String format) {
		this.format = format;
	}

	@Override
	public void doTag() throws JspException, IOException {
	
		super.doTag();
		
		
		 DateTimeFormatter dtf = DateTimeFormatter.ofPattern(format);  
		   LocalDateTime now = LocalDateTime.now();  
		   JspWriter out= getJspContext().getOut();
		   out.println("date in format: "+dtf.format(now));
		
	}
	
	
	

}
