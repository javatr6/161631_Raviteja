package com.cap.jpaDemo;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;


@Entity
public class Address {
	
	
	@Id
	private String AddressId;
	private String Address;
	
	
	@OneToOne
	@JoinColumn(name="cust_fk")
	private Customer customer;

	public Address() {
		
	}
	

	public Address(String addressId, String address, Customer customer) {
		super();
		AddressId = addressId;
		Address = address;
		this.customer = customer;
	}


	public String getAddressId() {
		return AddressId;
	}


	public void setAddressId(String addressId) {
		AddressId = addressId;
	}


	public String getAddress() {
		return Address;
	}


	public void setAddress(String address) {
		Address = address;
	}


	public Customer getCustomer() {
		return customer;
	}


	public void setCustomer(Customer customer) {
		this.customer = customer;
	}


	@Override
	public String toString() {
		return "Address [AddressId=" + AddressId + ", Address=" + Address + ", customer=" + customer + "]";
	}

	
	

}
