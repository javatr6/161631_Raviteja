package org.flp.capbook.beans;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import org.hibernate.annotations.CascadeType;


@Entity
public class UserProfile {
  
	@Id
	@GeneratedValue
	private Integer userId;
	private String userName;
	@OneToOne
	@JoinColumn(name="Addressfk")
	private Address address;
	private Boolean dob;
	private Boolean areaofIntrest;
	@OneToMany(mappedBy="user",targetEntity=Albums.class,cascade=CascadeType.ALL,fetch=FetchType.LAZY)
	private List<Albums> albums=new ArrayList<Albums>();
	private Boolean gender;
	private String mobileNo;
	
	
	
	
}
