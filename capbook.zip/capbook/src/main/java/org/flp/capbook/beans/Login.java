package org.flp.capbook.beans;

public class Login {

private String email;
private String password;
private String status;
private String activationURL;
private String activeStatus;

	
	
	
}
