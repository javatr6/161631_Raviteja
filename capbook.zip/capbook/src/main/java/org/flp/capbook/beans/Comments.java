package org.flp.capbook.beans;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.Id;
@Entity
public class Comments {

	@Id
	private Long commentId;
	private String commentText;
	private Long postedBy;
	private Long postedTo;
	private LocalDate dateOfPosting;
	private Long statusId;
	private Long likeCount;
	private Long dislikeCount;
	
	public Comments() {
		super();
	}

	public Comments(Long commentId, String commentText, Long postedBy, Long postedTo, LocalDate dateOfPosting, Long statusId,
			Long likeCount, Long dislikeCount) {
		super();
		this.commentId = commentId;
		this.commentText = commentText;
		this.postedBy = postedBy;
		this.postedTo = postedTo;
		this.dateOfPosting = dateOfPosting;
		this.statusId = statusId;
		this.likeCount = likeCount;
		this.dislikeCount = dislikeCount;
	}

	public Long getCommentId() {
		return commentId;
	}

	public void setCommentId(Long commentId) {
		this.commentId = commentId;
	}

	public String getCommentText() {
		return commentText;
	}

	public void setCommentText(String commentText) {
		this.commentText = commentText;
	}

	public Long getPostedBy() {
		return postedBy;
	}

	public void setPostedBy(Long postedBy) {
		this.postedBy = postedBy;
	}

	public Long getPostedTo() {
		return postedTo;
	}

	public void setPostedTo(Long postedTo) {
		this.postedTo = postedTo;
	}

	public LocalDate getDateOfPosting() {
		return dateOfPosting;
	}

	public void setDateOfPosting(LocalDate dateOfPosting) {
		this.dateOfPosting = dateOfPosting;
	}

	public Long getStatusId() {
		return statusId;
	}

	public void setStatusId(Long statusId) {
		this.statusId = statusId;
	}

	public Long getLikeCount() {
		return likeCount;
	}

	public void setLikeCount(Long likeCount) {
		this.likeCount = likeCount;
	}

	public Long getDislikeCount() {
		return dislikeCount;
	}

	public void setDislikeCount(Long dislikeCount) {
		this.dislikeCount = dislikeCount;
	}

	@Override
	public String toString() {
		return "Comments [commentId=" + commentId + ", commentText=" + commentText + ", postedBy=" + postedBy
				+ ", postedTo=" + postedTo + ", dateOfPosting=" + dateOfPosting + ", statusId=" + statusId
				+ ", likeCount=" + likeCount + ", dislikeCount=" + dislikeCount + "]";
	}
	
	
	
	
}
