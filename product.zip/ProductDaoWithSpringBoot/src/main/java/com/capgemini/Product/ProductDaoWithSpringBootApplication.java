package com.capgemini.Product;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductDaoWithSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductDaoWithSpringBootApplication.class, args);
	}
}
