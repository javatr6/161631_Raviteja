package org.flp.capbook.controller;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class UserController {
	public void checkLogin() {
		//Work goes here....
		System.out.println("Login Method Done...!");
	}

}
