package org.flp.capbook.controller;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.flp.capbook.model.Status;
import org.flp.capbook.service.IinventoryService;
import org.flp.capbook.service.StorageService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.method.annotation.MvcUriComponentsBuilder;







@RestController
@CrossOrigin(origins="*")
public class UserController {
	@Autowired
	private IinventoryService inventoryService;
	

	@Value("${upload.path}")
    private String path;

	List<String> files1 = new ArrayList<String>();

	@Autowired
	StorageService profileService;
 
	List<String> files = new ArrayList<String>();
 
	@PostMapping("/saveImage/{userId}")
	public ResponseEntity<String> handleFileUpload(@RequestBody Status status,@PathVariable("userId") Integer userId) {
		String message = "Uploaded successfully";
			profileService.store(status,userId);		
			return ResponseEntity.status(HttpStatus.OK).body(message);
	
	}
		
	
	@GetMapping("/getStatus/{userId}")
	public ResponseEntity<List<Status>> getStatus(@PathVariable("userId")Integer userId){
		
		List<Status> status = profileService.getStatus(userId);
		
		return ResponseEntity.status(HttpStatus.OK).body(status);
		
	}
			
	
}
