package org.cap.dao;

import org.cap.model.Login;

public interface ILoginDao {
public boolean validateLogin(Login login);
}
