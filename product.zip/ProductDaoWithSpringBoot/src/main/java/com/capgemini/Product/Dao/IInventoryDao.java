package com.capgemini.Product.Dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.Product.Model.Product;

@Repository("productDao")
@Transactional
public interface IInventoryDao extends JpaRepository<Product, Integer>{

}
