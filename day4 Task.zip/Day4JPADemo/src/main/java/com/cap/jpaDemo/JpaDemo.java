package com.cap.jpaDemo;

import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class JpaDemo {

	public static void main(String[] args) {
		
		Date d = new Date(23-02-1997);
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpademo");
		
		EntityManager entityManager = emf.createEntityManager();
		
		EntityTransaction transaction =entityManager.getTransaction();
		
		transaction.begin();
		
		Customer customer =new Customer("ravi",1000.00,new Date());
		
		
		
		
		entityManager.persist(customer);

		
		transaction.commit();
		

	}

}
