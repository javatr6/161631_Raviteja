package com.cap.jpaDemo;




import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class JpaTestDemo {
	public static void main(String []args) {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpademo");
		EntityManager entityManager=emf.createEntityManager();
		EntityTransaction transaction=entityManager.getTransaction();
		
		transaction.begin();
		Company zoho=new Company("google");
		Company adp=new Company("MicroDoft");
		
		Employee employee=new Employee(1,"Raviteja",zoho);
		Employee employee2=new Employee(2,"Vishwa teja",adp);
		Employee employee3=new Employee(3,"pardhu",adp);
		
		entityManager.persist(zoho);
		entityManager.persist(adp);
		entityManager.persist(employee);
		entityManager.persist(employee2);
		entityManager.persist(employee3);
		transaction.commit();
		entityManager.close();
	}

} 
 
