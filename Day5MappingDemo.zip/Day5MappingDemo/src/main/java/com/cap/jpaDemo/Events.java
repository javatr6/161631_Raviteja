package com.cap.jpaDemo;



	import java.util.ArrayList;
	import java.util.List;

	import javax.persistence.Entity;
	import javax.persistence.Id;
	import javax.persistence.JoinColumn;
	import javax.persistence.JoinTable;
	import javax.persistence.ManyToMany;
	@Entity
	public class Events {
		@Id
		private int event_id;
		private String event_name;
		
		@ManyToMany
		@JoinTable(name="event_delegate",joinColumns= {@JoinColumn(name="event_name")},
		inverseJoinColumns= {@JoinColumn(name="delegateId")})
		
		private List<Delegates> delegates=new ArrayList<Delegates>();

		public int getEvent_id() {
			return event_id;
		}

		public void setEvent_id(int event_id) {
			this.event_id = event_id;
		}

		public String getEvent_name() {
			return event_name;
		}

		public void setEvent_name(String event_name) {
			this.event_name = event_name;
		}

		public List<Delegates> getDelegates() {
			return delegates;
		}

		public void setDelegates(List<Delegates> delegates) {
			this.delegates = delegates;
		}

		public Events(int event_id, String event_name, List<Delegates> delegates) {
			super();
			this.event_id = event_id;
			this.event_name = event_name;
			this.delegates = delegates;
		}

		public Events(int event_id, String event_name) {
			super();
			this.event_id = event_id;
			this.event_name = event_name;
		}

		@Override
		public String toString() {
			return "Events [event_id=" + event_id + ", event_name=" + event_name + ", delegates=" + delegates + "]";
		}
		
	} 
	 

	
	

