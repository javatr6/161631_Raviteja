package com.cap.Example;

import java.io.IOException;
import java.io.StringWriter;
import java.time.LocalDateTime;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.SimpleTagSupport;

public class CurrentDateMsg extends SimpleTagSupport{

	@Override
	public void doTag() throws JspException, IOException {
		super.doTag();
		LocalDateTime now = LocalDateTime.now();
		JspWriter out= getJspContext().getOut();
		StringWriter writer=new StringWriter();
		getJspBody().invoke(writer);
		out.println(writer+"<h1>today's date is: "+now+"</h1>");
		
		
	}
	
	

}
