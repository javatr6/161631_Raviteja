package com.cap.Example;

import java.io.IOException;
import java.time.LocalDateTime;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.SimpleTagSupport;

public class CurrentDateDemo extends SimpleTagSupport{

	
	@Override
	public void doTag() throws JspException, IOException {
		
		super.doTag();
		
		JspWriter out= getJspContext().getOut();
		LocalDateTime now = LocalDateTime.now();
		out.println("<h1>today's date is: "+now+"</h1>");
	}  
	
	
	
		
		

	

}
