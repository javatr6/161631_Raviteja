package com.cap.Dao;

import java.util.List;

import com.cap.Model.Product;

public interface IProductDao {
	
	public List<Product> getAllProducts();
	public List<Product> deleteProducts(Integer productId);
	public List<Product> addProducts(Integer productId, String productName);
	public List<Product> updateProducts(Integer productId, String productName);
	public Product findProducts(Integer productId);

}
